import Foundation

class UserAuth: ObservableObject {
    @Published var isLoggedin = false
}
